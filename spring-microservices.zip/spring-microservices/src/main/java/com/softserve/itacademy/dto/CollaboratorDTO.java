package com.softserve.itacademy.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CollaboratorDTO {
    @NotNull
    private long collaborator_id;
}